# Using-hydrochemistry-and-simple-visualization-to-differentiate-groundwater-samples
This repo is connected to Authorea article with the same title. 
